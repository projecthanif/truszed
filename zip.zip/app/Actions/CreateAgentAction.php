<?php

namespace App\Actions;

class CreateAgentAction
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
