<?php

namespace App\Actions;

class CreateUserAction
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
